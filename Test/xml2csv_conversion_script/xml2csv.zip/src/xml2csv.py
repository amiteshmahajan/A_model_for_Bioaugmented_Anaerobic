from BeautifulSoup import BeautifulStoneSoup
import zipfile
import os
import platform
import sys
import shutil
import numpy

commentChar = ''

def extractAgentStates(path, commentChar):
	agentStateZip = zipfile.ZipFile(path+'agent_State.zip', 'r')
	if platform.system == 'Windows':
		try:
			os.mkdir('agent_States')
		except WindowsError:
			print('Directory already exists. Skipping creation.')
	else:
		try:
			os.mkdir('agent_States')
		except OSError:
			print('Directory already exists. Skipping creation.')

	agentStateZip.extractall('agent_States')

	numfiles = len(os.listdir('agent_States'))

	filenames = ['agent_States/agent_State('+str(i)+').xml' for i in xrange(numfiles)]

	speciesDict = {}

	numSpeciesEncountered = 0

	for filename in filenames:
		xmlFile = open(filename, 'rU')
		soup = BeautifulStoneSoup(xmlFile.read(), selfClosingTags='grid')
		xmlFile.close()
		timestep = dict(soup.simulation.attrs)['iterate']
		gridDict = dict(soup.grid.attrs)
		speciesList = soup('species')
		header = ''

		speciesData = []
		for spp in speciesList:
			speciesAttrs = dict(spp.attrs)
			if(len(header) < len('species_id,' + 'resolution,' + 'grid_ni,' + 'grid_nj,' + 'grid_nk,' + speciesAttrs['header'] + '\n')):
				header = 'species_id,' + 'resolution,' + 'grid_ni,' + 'grid_nj,' + 'grid_nk,' + speciesAttrs['header'] + '\n'

			sppName = speciesAttrs['name']
			if(sppName not in speciesDict.keys()):
				speciesDict[sppName] = numSpeciesEncountered
				numSpeciesEncountered += 1
			speciesDataList = spp.contents.pop().split(';')
			speciesDataList = [someStr.strip() for someStr in speciesDataList]

			for data in speciesDataList[:-1]:
				speciesData += str(speciesDict[sppName]) + ',' + gridDict['resolution'] + ',' + gridDict['ni'] + ',' + gridDict['nj'] + ',' + gridDict['nk'] + ',' + ''.join(data) + '\n'
			
		outfile = open('agent_State('+str(timestep)+').csv', 'wb')
		outfile.write(commentChar+'Species name: species id\n')
		outfile.write(commentChar)
		outfile.write(''.join([speciesName+':'+str(speciesDict[speciesName])+' ' for speciesName in speciesDict.keys()]))
		outfile.write('\n')
		outfile.write(commentChar)
		outfile.write(''.join(header))
		outfile.write(''.join(speciesData))
		outfile.close()


def extractEnvStates(path, commentChar):
	envStateZip = zipfile.ZipFile(path+'env_State.zip', 'r')
	if platform.system == 'Windows':
		'''Running in Windows. This is required because Windows throws a different exception in case the directory already exists.'''
		try:
			os.mkdir('env_States')
		except WindowsError:
			print('Directory already exists. Skipping creation.')
	else:
		'''Running in *NIX. The script does NOT handle the case that you are running a non-Windows, non-*NIX OS. It has been tested in Windows XP and Vista as well as Linux and Mac OS X. It should also work in any *BSD'''
		try:
			os.mkdir('env_States')
		except OSError:
			print('Directory already exists. Skipping creation.')

	envStateZip.extractall('env_States')

	numfiles = len(os.listdir('env_States'))

	filenames = ['env_States/env_State('+str(i)+').xml' for i in xrange(numfiles)]

	soluteDict = {}

	numSolutesEncountered = 0

	for filename in filenames:
		xmlFile = open(filename, 'rU')
		soup = BeautifulStoneSoup(xmlFile.read(), selfClosingTags='grid')
		xmlFile.close()
		timestep = dict(soup.simulation.attrs)['iterate']
		soluteList = soup('solute')

		header = 'solute_id,' + 'location_x,' + 'location_y,' + 'location_z,' + 'concentration' + '\n'
		
		nI = 0
		nJ = 0
		nK = 0
		resolution = 0

		soluteData = []
		soluteDataArray = None
		for solute in soluteList:
			soluteAttrs = dict(solute.attrs)
			nI = int(soluteAttrs['ni'])
			nJ = int(soluteAttrs['nj'])
			nK = int(soluteAttrs['nk'])
			resolution = soluteAttrs['resolution']

			soluteName = soluteAttrs['name']
			if(soluteName not in soluteDict.keys()):
				soluteDict[soluteName] = numSolutesEncountered				
				numSolutesEncountered += 1

			soluteDataList = solute.contents.pop().split(';')			
			soluteDataList = [s.strip() for s in soluteDataList if s.strip() is not u''] #clear blank lines
			soluteDataNumList = []
			for n, element in enumerate(soluteDataList):
				soluteDataList[n] = soluteDataList[n].replace('[', '')
				soluteDataList[n] = soluteDataList[n].replace(']', '')
				soluteDataList[n] = soluteDataList[n].strip()
				nums = [float(i) for i in soluteDataList[n].split(',')]
				soluteDataNumList.append(nums)

			soluteDataArray = isShaped(numpy.array(soluteDataNumList), int(soluteAttrs['ni']), int(soluteAttrs['nj']), int(soluteAttrs['nk']))
			soluteData.append(soluteDataArray)
			
			
		print len(soluteData)
		
		outfile = open('env_State('+str(timestep)+').csv', 'wb')
		outfile.write(commentChar)
		outfile.write('resolution = ' + str(resolution))
		outfile.write('\n')
		outfile.write(commentChar)
		outfile.write('Solute name: solute id')
		outfile.write('\n')
		outfile.write(commentChar)
		outfile.write(''.join([soluteName+':'+str(soluteDict[soluteName])+' ' for soluteName in soluteDict.keys()]))
		outfile.write('\n')
		outfile.write(commentChar)
		outfile.write(''.join(header))
		for soluteNum, solute in enumerate(soluteData):
			for i in xrange(nI):
				for j in xrange(nJ):
					for k in xrange(nK):
						outfile.write(str(soluteNum) + ' ,' + str(i) + ' ,' + str(j) + ' ,' + str(k) + ' ,' + str(solute[i, j, k]))
						outfile.write('\n')
						

		outfile.close()

def isShaped(x, nI, nJ, nK):
	nX=x.shape[0]
	nY=x.shape[1]
	try:
		nZ=x.shape[2]
	except IndexError:
		nZ = 1

	if(nX*nY*nZ)==(nI*nJ*nK):
		# No padding
		x = x.reshape(nI,nJ,nK)
		#x = x.transpose([1,0,2])
	elif (nX*nY*nZ)==(nI+2)*(nJ+2)*(nK+2):
		# padding
		x   = x.reshape(nI+2,nJ+2,nK+2)
		#x = x.transpose([1,0,2])
		x   = x[1:-1,1:-1,1:-1]
	
	return x
		
def cleanup():
	try:
		shutil.rmtree('agent_States')
		shutil.rmtree('env_States')	
	except:
		print 'Unable to remove temporary files. You may have to manually delete the agent_States and env_States directories'

if __name__ == '__main__':
	if len(sys.argv) == 3:
		path = sys.argv[1]
		commentChar = sys.argv[2]
	elif len(sys.argv) == 2:
		path = sys.argv[1]
		commentChar = ''
	else:
		print "Usage:\nIf using python: python xml2csv.py path_to_results_zips character_to_start_comments_with\nIf using exe: xml2csv path_to_results_zips character_to_start_comments_with"
		exit()
	
	path = path.replace('\\','/')

	if not path.endswith('/'):
		path = path + '/'
	
	try:
		print('Extracting information for agents...')
		extractAgentStates(path, commentChar)
		print('Extracting information for environment...')
		extractEnvStates(path, commentChar)
	finally:
		cleanup()
